<!-- Simulated ai-voice-data.js for V3 PREMIUM -->
