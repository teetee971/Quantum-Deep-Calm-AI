#!/bin/bash
echo 'OK'