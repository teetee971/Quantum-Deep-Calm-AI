# Quantum Deep Calm AI

Site immersif propulsé par IA quantique.

## Pages
- `index.html`
- `about.html`
- `contact.html`
- `404.html`

## Déploiement
```
git init
git add .
git commit -m "Déploiement complet"
git branch -M main
git remote add origin <url>
git push -u origin main
```